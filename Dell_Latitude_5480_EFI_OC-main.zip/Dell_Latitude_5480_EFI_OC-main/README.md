# Dell_Latitude_5480_EFI

**CURRENT:** Monterey 12.3.1 using OC 0.7.5


## Specs

- CPU: Intel i5-6 2.5 GHz(Skylake)
- DISK: 265GB M.2 PCIe SSD
- GPU: Intel HD Grapics 520

## Working

- Wifi
- Touchscreen
- Intergrated Webcam
- Backlight
- USB-A/C ports
- Audio
- Power management
- Dell sensors
- SFD card reader
- HDMI Port
- Keyboard
- Trackpad + Gestures
- Bluetooth

## Not working
 
 - Report an issue

## TODO

- Update to OC 0.8
